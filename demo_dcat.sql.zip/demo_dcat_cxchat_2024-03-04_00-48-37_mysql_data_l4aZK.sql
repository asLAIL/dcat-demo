-- MySQL dump 10.13  Distrib 5.7.40, for Linux (x86_64)
--
-- Host: localhost    Database: demo_dcat_cxchat
-- ------------------------------------------------------
-- Server version	5.7.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_extension_histories`
--

DROP TABLE IF EXISTS `admin_extension_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_extension_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '1',
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `detail` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_extension_histories_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_extension_histories`
--

LOCK TABLES `admin_extension_histories` WRITE;
/*!40000 ALTER TABLE `admin_extension_histories` DISABLE KEYS */;
INSERT INTO `admin_extension_histories` VALUES (1,'guanguans.dcat-login-captcha',1,'1.0.0','Initial release.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(2,'guanguans.dcat-login-captcha',1,'1.0.1','Add default config file.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(3,'guanguans.dcat-login-captcha',1,'1.0.1','Add annotation for facades.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(4,'guanguans.dcat-login-captcha',1,'1.0.1','Optimize `login_captcha_check` function.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(5,'guanguans.dcat-login-captcha',1,'1.0.1','Optimize captcha generate.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(6,'guanguans.dcat-login-captcha',1,'1.0.1','Optimize get setting config.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(7,'guanguans.dcat-login-captcha',1,'1.0.1','Rename `dcat_login_captcha_check`->`login_captcha_check`.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(8,'guanguans.dcat-login-captcha',1,'1.0.1','Rename `dcat_login_captcha_url`->`login_captcha_url`.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(9,'guanguans.dcat-login-captcha',1,'1.0.2','Add login_captcha_get function.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(10,'guanguans.dcat-login-captcha',1,'1.0.2','Update lang files.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(11,'guanguans.dcat-login-captcha',1,'1.0.2','Update extension alias and description.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(12,'guanguans.dcat-login-captcha',1,'1.0.2','Optimize LoginCaptchaServiceProvider.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(13,'guanguans.dcat-login-captcha',1,'1.0.2','Optimize setting form.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(14,'guanguans.dcat-login-captcha',1,'1.0.3','Add CleanObContents Middleware.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(15,'guanguans.dcat-login-captcha',1,'1.0.4','Add SetResponseContentType Middleware.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(16,'guanguans.dcat-login-captcha',1,'1.0.4','Add content type setting config.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(17,'guanguans.dcat-login-captcha',1,'1.0.5','Add BootingHandler.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(18,'guanguans.dcat-login-captcha',1,'1.0.6','Rename src/BootingAdmin.php -> src/BootingHandler.php.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(19,'guanguans.dcat-login-captcha',1,'1.0.6','Remove src/Http/Controllers/CaptchaController.php`.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(20,'guanguans.dcat-login-captcha',1,'1.0.7','Optimize `buildCaptchaJsScript`.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(21,'guanguans.dcat-login-captcha',1,'1.0.8','Fix cant match routing path(#8).','2023-09-15 06:13:47','2023-09-15 06:13:47'),(22,'guanguans.dcat-login-captcha',1,'1.0.9','Add parameters to the `SetResponseContentType` middleware.','2023-09-15 06:13:47','2023-09-15 06:13:47'),(23,'guanguans.dcat-login-captcha',1,'1.0.9','Update github config files.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(24,'guanguans.dcat-login-captcha',1,'1.0.9','Update phpunit/phpunit requirement from ^7.0 || ^8.0 to ^7.0 || ^8.0 || ^9.0.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(25,'guanguans.dcat-login-captcha',1,'1.0.9','Optimize booting `BootingHandler`.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(26,'guanguans.dcat-login-captcha',1,'1.0.9','Optimize setting form .','2023-09-15 06:13:48','2023-09-15 06:13:48'),(27,'guanguans.dcat-login-captcha',1,'1.0.10','Compatible callback type.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(28,'guanguans.dcat-login-captcha',1,'1.0.11','Rename `phrase_session_key` -> `captcha_phrase_session_key`.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(29,'guanguans.dcat-login-captcha',1,'1.0.11','Generate captcha random url.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(30,'guanguans.dcat-login-captcha',1,'1.0.11','Replace `Closure routing` -> `CaptchaController`.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(31,'guanguans.dcat-login-captcha',1,'1.0.11','Bump actions/cache from 2 to 3.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(32,'guanguans.dcat-login-captcha',1,'1.0.11','Bump actions/checkout from 2 to 3.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(33,'guanguans.dcat-login-captcha',1,'1.0.11','Update overtrue/phplint requirement from ^2.3 || ^3.0 to ^2.3 || ^3.0 || ^4.0.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(34,'guanguans.dcat-login-captcha',1,'1.0.12','Bump codecov/codecov-action from 2.1.0 to 3.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(35,'guanguans.dcat-login-captcha',1,'1.0.12','Update author info.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(36,'guanguans.dcat-login-captcha',1,'1.0.13','Update JS.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(37,'guanguans.dcat-login-captcha',1,'1.0.14','Rename login_captcha_get -> login_captcha_content.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(38,'guanguans.dcat-login-captcha',1,'1.0.14','Update github config files.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(39,'guanguans.dcat-login-captcha',1,'1.0.15','Fix captcha check.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(40,'guanguans.dcat-login-captcha',1,'1.0.16','Add migration files.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(41,'guanguans.dcat-login-captcha',1,'1.0.17','Fix migration file name.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(42,'guanguans.dcat-login-captcha',1,'1.0.18','Update to single action controller.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(43,'guanguans.dcat-login-captcha',1,'1.0.18','Fix setting.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(44,'guanguans.dcat-login-captcha',1,'1.0.18','Optimize migration file.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(45,'guanguans.dcat-login-captcha',1,'1.0.19','Fix loading config.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(46,'guanguans.dcat-login-captcha',1,'1.0.19','Remove version update migration.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(47,'guanguans.dcat-login-captcha',1,'1.0.19','Cancel service late registration.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(48,'guanguans.dcat-login-captcha',1,'1.1.0','chore(deps): update overtrue/phplint to support more versions.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(49,'guanguans.dcat-login-captcha',1,'1.1.0','update LoginCaptchaServiceProvider.php to merge config correctly(#27).','2023-09-15 06:13:48','2023-09-15 06:13:48'),(50,'guanguans.dcat-login-captcha',1,'1.1.0','Bump dependabot/fetch-metadata from 1.3.5 to 1.3.6.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(51,'guanguans.dcat-login-captcha',1,'1.1.0','Bump actions/stale from 6 to 7.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(52,'guanguans.dcat-login-captcha',1,'1.1.0','Update vimeo/psalm requirement from ^4.0 to ^4.0 || ^5.0.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(53,'guanguans.dcat-login-captcha',1,'1.1.0','Bump dependabot/fetch-metadata from 1.3.4 to 1.3.5.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(54,'guanguans.dcat-login-captcha',1,'1.1.0','Bump dependabot/fetch-metadata from 1.3.3 to 1.3.4.','2023-09-15 06:13:48','2023-09-15 06:13:48'),(55,'guanguans.dcat-login-captcha',1,'1.1.0','Bump actions/stale from 5 to 6.','2023-09-15 06:13:48','2023-09-15 06:13:48');
/*!40000 ALTER TABLE `admin_extension_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_extensions`
--

DROP TABLE IF EXISTS `admin_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_extensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_enabled` tinyint(4) NOT NULL DEFAULT '0',
  `options` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_extensions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_extensions`
--

LOCK TABLES `admin_extensions` WRITE;
/*!40000 ALTER TABLE `admin_extensions` DISABLE KEYS */;
INSERT INTO `admin_extensions` VALUES (1,'guanguans.dcat-login-captcha','1.1.0',1,NULL,'2023-09-15 06:13:47','2023-09-15 06:13:53');
/*!40000 ALTER TABLE `admin_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_menu`
--

DROP TABLE IF EXISTS `admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uri` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `show` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_menu`
--

LOCK TABLES `admin_menu` WRITE;
/*!40000 ALTER TABLE `admin_menu` DISABLE KEYS */;
INSERT INTO `admin_menu` VALUES (1,0,1,'Index','feather icon-bar-chart-2','/','',1,'2023-08-15 23:39:32',NULL),(2,0,2,'Admin','feather icon-settings','','',1,'2023-08-15 23:39:32',NULL),(3,2,3,'Users','','auth/users','',1,'2023-08-15 23:39:32',NULL),(4,2,4,'Roles','','auth/roles','',1,'2023-08-15 23:39:32',NULL),(5,2,5,'Permission','','auth/permissions','',1,'2023-08-15 23:39:32',NULL),(6,2,6,'Menu','','auth/menu','',1,'2023-08-15 23:39:32',NULL),(7,2,7,'Extensions','','auth/extensions','',1,'2023-08-15 23:39:32',NULL),(8,0,8,'系统设置','fa-arrows','sys/config','',1,'2023-08-31 07:16:54','2023-09-14 16:58:56');
/*!40000 ALTER TABLE `admin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_permission_menu`
--

DROP TABLE IF EXISTS `admin_permission_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permission_menu` (
  `permission_id` bigint(20) NOT NULL,
  `menu_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `admin_permission_menu_permission_id_menu_id_unique` (`permission_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permission_menu`
--

LOCK TABLES `admin_permission_menu` WRITE;
/*!40000 ALTER TABLE `admin_permission_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_permission_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_permissions`
--

DROP TABLE IF EXISTS `admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '0',
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permissions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permissions`
--

LOCK TABLES `admin_permissions` WRITE;
/*!40000 ALTER TABLE `admin_permissions` DISABLE KEYS */;
INSERT INTO `admin_permissions` VALUES (1,'Auth management','auth-management','','',1,0,'2023-08-15 23:39:32',NULL),(2,'Users','users','','/auth/users*',2,1,'2023-08-15 23:39:32',NULL),(3,'Roles','roles','','/auth/roles*',3,1,'2023-08-15 23:39:32',NULL),(4,'Permissions','permissions','','/auth/permissions*',4,1,'2023-08-15 23:39:32',NULL),(5,'Menu','menu','','/auth/menu*',5,1,'2023-08-15 23:39:32',NULL),(6,'Extension','extension','','/auth/extensions*',6,1,'2023-08-15 23:39:32',NULL);
/*!40000 ALTER TABLE `admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_menu`
--

DROP TABLE IF EXISTS `admin_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_menu` (
  `role_id` bigint(20) NOT NULL,
  `menu_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `admin_role_menu_role_id_menu_id_unique` (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_menu`
--

LOCK TABLES `admin_role_menu` WRITE;
/*!40000 ALTER TABLE `admin_role_menu` DISABLE KEYS */;
INSERT INTO `admin_role_menu` VALUES (1,8,'2023-08-31 07:16:54','2023-08-31 07:16:54');
/*!40000 ALTER TABLE `admin_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permissions`
--

DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `role_id` bigint(20) NOT NULL,
  `permission_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `admin_role_permissions_role_id_permission_id_unique` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permissions`
--

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_users`
--

DROP TABLE IF EXISTS `admin_role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_users` (
  `role_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `admin_role_users_role_id_user_id_unique` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_users`
--

LOCK TABLES `admin_role_users` WRITE;
/*!40000 ALTER TABLE `admin_role_users` DISABLE KEYS */;
INSERT INTO `admin_role_users` VALUES (1,1,'2023-08-15 23:39:32','2023-08-15 23:39:32');
/*!40000 ALTER TABLE `admin_role_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_roles`
--

DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_roles`
--

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,'Administrator','administrator','2023-08-15 23:39:32','2023-08-15 23:39:32');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_settings`
--

DROP TABLE IF EXISTS `admin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_settings` (
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_settings`
--

LOCK TABLES `admin_settings` WRITE;
/*!40000 ALTER TABLE `admin_settings` DISABLE KEYS */;
INSERT INTO `admin_settings` VALUES ('guanguans:dcat-login-captcha','{\"length\":4,\"charset\":\"abcdefghijklmnpqrstuvwxyz23456789ABCDEFGHIJKLMNOPQRSTUVWXYZ\",\"width\":150,\"height\":43,\"type\":\"png\",\"font\":null,\"fingerprint\":null,\"captcha_phrase_session_key\":\"login_captcha_phrase\"}','2023-09-15 06:13:53','2023-09-15 06:13:53');
/*!40000 ALTER TABLE `admin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$K.Ns/JZUaYXem4pNyLtZBeYKK2rcksZf61vwNIlko6Ca50uHNyGJm','Administrator',NULL,NULL,'2023-08-15 23:39:32','2023-08-15 23:39:32');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_04_173148_create_admin_tables',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2020_09_07_090635_create_admin_settings_table',1),(7,'2020_09_22_015815_create_admin_extensions_table',1),(8,'2020_11_01_083237_update_admin_menu_table',1),(9,'2019_04_23_154507_create_posts_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'21213','sanner@tom.com',NULL,NULL,'$2y$10$VLzdlRgMIrDrjBsS0Riz4OGecb9VqPjEH48z6PBVTMJW0wRU6ENwS',NULL,'2023-09-15 07:23:31','2023-09-28 06:40:26'),(5,'sanner213',NULL,NULL,NULL,'$2y$10$jtVv/jZexXyB90ER55GUcuoKBCAUEChAFyjBHyQllqye.MUgW4ijm',NULL,'2023-09-28 06:38:11','2023-09-28 06:38:11');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'demo_dcat_cxchat'
--

--
-- Dumping routines for database 'demo_dcat_cxchat'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-04  0:48:38
